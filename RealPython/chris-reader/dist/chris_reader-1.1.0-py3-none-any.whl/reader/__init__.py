# Version of the realpython-reader package
__version__ = "1.1.0"